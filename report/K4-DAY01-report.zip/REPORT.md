# Báo cáo bài thực hành Ngày 1 – Đọc nhãn từ đầu ra YOLO11

**Ngày chạy:** 2026-09-11

**Runtime Colab:** CPU (môi trường thực thi CPU, tương thích CPU và T4 GPU)

**Python / PyTorch / Ultralytics:** Python 3.13.13 / PyTorch 2.11.0 / Ultralytics 8.4.145

**Checkpoint:** `yolo11n-cls.pt`, `yolo11n.pt`, `yolo11n-seg.pt`

**Thay đổi so với notebook nguồn:** Không (giữ nguyên cấu hình, threshold và pipeline chuẩn của notebook release v1.0.2)

> ZIP do notebook tạo có tên `<KHOA>-DAY01-report.zip` (ví dụ: `K4-DAY01-report.zip`). Giải nén rồi đặt trực tiếp `REPORT.md` và
> `day1_lab_outputs/` vào thư mục `report/` của repository tạo từ template. Không ghi họ tên, MSSV,
> email, số điện thoại hoặc dữ liệu cá nhân khác. Nộp link repository trên VLearn; tài khoản VLearn xác
> định người nộp.

## 1. Phân loại ảnh – prediction cấp ảnh

Nguồn evidence: `classification_predictions.json`, sample `traffic`.

- Record hạng 1 (`class_id`, `class_name`, `rank`, `score`, `taxonomy_name`):
  - `class_id`: 468
  - `class_name`: "cab"
  - `rank`: 1
  - `score`: 0.510915
  - `taxonomy_name`: "ImageNet-1K"
  *(Chi tiết record: sample `traffic`, COCO image ID `210273`, kích thước `640 x 428` pixel, tạo bởi checkpoint `yolo11n-cls.pt`, SHA-256 `c62d41bf9625777760018bf914d2e6cd472420ccd01706d97a61cb6c82502bd7`, phiên bản `ultralytics==8.4.145`).*

- Record này mô tả toàn ảnh như thế nào?
  Trong tác vụ phân loại ảnh (image classification), mô hình dự đoán một nhãn phân loại duy nhất đại diện cho ngữ nghĩa toàn cục của toàn bộ bức ảnh (image-level prediction). Nhãn `cab` (xe taxi) với `score = 0.510915` được mô hình xếp hạng 1 (rank 1) trong không gian 1.000 danh mục của ImageNet-1K, mang ý nghĩa rằng đặc trưng tổng thể của bức ảnh giao thông đô thị này khớp gần nhất với phân phối của lớp `cab`. Record này mô tả trạng thái ngữ nghĩa của toàn bộ khung hình, hoàn toàn không gắn với bất kỳ tọa độ không gian (bounding box hay polygon) nào, và không xác định được vị trí hay số lượng của chiếc taxi cụ thể nào trong ảnh.

- Ai định nghĩa class list mà checkpoint có thể dự đoán?
  Danh mục lớp (class list) do nhóm thiết kế tập dữ liệu huấn luyện và quy chuẩn bản thể học (ontology / taxonomy) định nghĩa từ trước (ở đây là bộ dữ liệu ImageNet-1K / ILSVRC với 1.000 lớp cố định dựa trên cây từ vựng WordNet). Mô hình máy học không tự nghĩ ra hoặc tự sáng tạo thêm danh mục lớp mới; không gian đầu ra (output space) của mô hình bị ràng buộc hoàn toàn vào 1.000 lớp có sẵn trong checkpoint đã huấn luyện.

- Vì sao cần giữ cả ID, tên lớp và tên taxonomy?
  1. `class_id`: Đảm bảo tính định danh số duy nhất (machine-readable ID), tránh lỗi tương thích phần mềm, chuẩn hóa chỉ mục tensor đầu ra và không bị phụ thuộc vào bảng mã ký tự hay ngôn ngữ.
  2. `class_name`: Cho phép con người (annotator, reviewer, kỹ sư dữ liệu) đọc hiểu ngữ nghĩa trực tiếp mà không cần bảng tra cứu mã ngược.
  3. `taxonomy_name`: Xác định không gian ngữ nghĩa và quy chuẩn phân loại (ví dụ: `ImageNet-1K` phân tách chi tiết thành `cab`, `minibus`, `police_van`, trong khi `COCO-80` gom chung lại thành `car` hoặc `bus`). Nếu thiếu tên taxonomy, hệ thống sẽ gặp xung đột ngữ nghĩa nghiêm trọng khi tích hợp dữ liệu từ nhiều mô hình hoặc chuyển giao giữa các dự án gán nhãn khác nhau.

- Nếu ảnh có nhiều chủ thể, guideline cần quy định điều gì?
  Khi ảnh chứa nhiều chủ thể cùng lúc (như ảnh `traffic` gồm nhiều xe buýt lớn, ô tô con, người đi bộ, dải phân cách, khói bụi), guideline phân loại ảnh đơn nhãn (single-label) bắt buộc phải quy định rõ:
  1. *Quy tắc ưu tiên chủ thể (Dominance / Salience Rule):* Ưu tiên chọn lớp theo chủ thể chiếm diện tích bề mặt lớn nhất ở tiền cảnh, chủ thể nằm ở trung tâm điểm nhìn, hay hành động nổi bật nhất trong cảnh.
  2. *Quy tắc phân cấp ưu tiên (Hierarchy Priority):* Xác định thứ tự ưu tiên giữa các loại đối tượng (ví dụ: ưu tiên phương tiện vận tải công cộng hay phương tiện cá nhân, hoặc ưu tiên khung cảnh chung hơn là phương tiện riêng lẻ).
  3. *Quy tắc xử lý ảnh mơ hồ (Ambiguity handling):* Nếu các chủ thể có độ nổi bật ngang nhau và việc gán 1 nhãn làm mất mát thông tin quan trọng, guideline cần quy định gán nhãn ngoại lệ (`ambiguous` / `other`) hoặc quy định chuyển đổi bài toán sang phân loại đa nhãn (multi-label classification) hoặc phát hiện vật thể (object detection).

- Vì sao model score không phải ground truth?
  `score` (hoặc confidence) chỉ là giá trị kích hoạt đầu ra mang tính thống kê (xác suất softmax của mạng nơ-ron) biểu thị độ tự tin toán học của mô hình dựa trên trọng số đã học. Điểm số cao không đồng nghĩa với việc dự đoán đó là sự thật khách quan (ví dụ trong ảnh `traffic`, chiếc xe buýt lớn màu xanh chiếm trọn tiền cảnh bên trái nhưng mô hình vẫn dự đoán `cab` ở rank 1 với score 0.510915 và chỉ xếp `minibus` ở rank 2 với score 0.164285). Ngược lại, **Ground Truth** là sự thật chuẩn mực do con người xác minh và ghi nhận dựa trên quan sát thực tế và tuân thủ chặt chẽ theo guideline được phê duyệt.

## 2. Phát hiện vật thể – lớp và box cho từng object

Nguồn evidence: `detection_predictions.json` và `visuals/detection_predictions.png`, sample `kitchen`.

- Một record (`class_name`, `score`, `bbox_xyxy`, `bbox_width`, `bbox_height`):
  - `class_name`: "person"
  - `score`: 0.912624
  - `bbox_xyxy`: `[385.33, 69.24, 498.92, 348.92]`
  - `bbox_width`: 113.58
  - `bbox_height`: 279.68
  *(Record khác có thể tham chiếu: `bowl` ở tiền cảnh bàn bếp với `score`: 0.719063, `bbox_xyxy`: `[32.65, 342.12, 100.16, 384.93]`, `bbox_width`: 67.51, `bbox_height`: 42.81).*

- Diễn giải vị trí box bằng lời:
  Hệ tọa độ ảnh sử dụng gốc `(0, 0)` tại góc trên cùng bên trái của bức ảnh kích thước `640 x 427` pixel:
  - Tọa độ góc trên-trái của box người đầu bếp là `(x_min = 385.33, y_min = 69.24)` pixel, nằm ở phía bên phải trục giữa của ảnh và cách mép trên 69.24 pixel (bắt đầu từ đỉnh đầu của người đầu bếp).
  - Tọa độ góc dưới-phải của box là `(x_max = 498.92, y_max = 348.92)` pixel, kết thúc ở gần gấu quần/chân người đầu bếp, cách mép trên 348.92 pixel.
  - Bounding box có chiều rộng `bbox_width = 113.58` pixel và chiều cao `bbox_height = 279.68` pixel, bao bọc vừa vặn toàn bộ vóc dáng người đầu bếp mặc áo trắng, đeo dây yếm tạp dề đang đứng quay lưng làm bếp.

- So sánh số prediction ở hai threshold:
  Thực nghiệm trên sample `kitchen` tại các ngưỡng điểm tin cậy:
  - Tại `threshold = 0.35` (ngưỡng mặc định của bài thực hành): mô hình phát hiện **11 vật thể** gồm 2 `person`, 5 `bowl`, 2 `oven`, 2 `cup`.
  - Tại `threshold = 0.60`: số lượng vật thể giảm xuống còn **6 vật thể** gồm 2 `person`, 2 `bowl`, 2 `oven` (các vật thể có score thấp hơn như 2 chiếc `cup` và 3 chiếc `bowl` nhỏ/bị che khuất đã bị lọc bỏ).
  - *(Khi hạ xuống `threshold = 0.20`: số lượng phát hiện tăng lên **17 vật thể**, xuất hiện thêm các lớp có điểm tin cậy thấp gồm 3 `spoon`, 1 `potted plant`, 1 `dining table`, 1 `bottle`).*

- Điều gì thay đổi đối với độ bao phủ và khối lượng reviewer cần xem?
  - *Khi hạ threshold (từ 0.60 xuống 0.35 hoặc 0.20):* Độ bao phủ (coverage / recall) tăng lên, giữ lại được các vật thể nhỏ hoặc mờ (như cốc, bát gia vị). Tuy nhiên, khối lượng công việc của reviewer tăng mạnh do phải kiểm tra nhiều box hơn, đồng thời tỷ lệ dương tính giả (false positives) tăng cao (ví dụ: bàn tay ở sát mép trái ảnh bị nhận nhầm thành một đối tượng `person` riêng biệt với score 0.61093), đòi hỏi reviewer phải thực hiện nhiều thao tác xóa hoặc sửa nhãn.
  - *Khi nâng threshold (từ 0.35 lên 0.60):* Độ chính xác (precision) cao hơn, số lượng box ít và sạch hơn, giảm thời gian review; tuy nhiên độ bao phủ giảm sút (tăng âm tính giả - false negatives), bỏ sót nhiều vật thể có thật, buộc annotator phải mất công vẽ bù thủ công từ đầu.

- Đề xuất một quy tắc box chặt:
  *Quy tắc Khung Hộp Chặt (Tight Bounding Box Rule):* Khung chữ nhật gán nhãn phải tiếp xúc sát nhất có thể (chạm vào các pixel biên ngoài cùng) với cả 4 cạnh giới hạn (trên, dưới, trái, phải) của vật thể nhìn thấy được; dung sai khoảng trống thừa ra phông nền không vượt quá 2 pixel, và tuyệt đối không cắt lẹm vào phần thân thể hiện của vật thể.

- Với object bị che khuất/cắt mép, điều gì cần guideline hoặc escalation quyết định?
  1. *Vật thể bị cắt mép ảnh (Truncation):* Guideline cần xác định rõ tỷ lệ hiển thị tối thiểu (ví dụ: vật thể phải lộ diện $\ge 20\%$ diện tích hoặc nhìn rõ các đặc trưng nhận dạng cốt lõi thì mới gán nhãn; đối với cánh tay/bàn tay ở rìa trái `kitchen`, guideline phải quy định rõ là vẽ nhãn `person` hay bỏ qua).
  2. *Vật thể bị che khuất (Occlusion):* Guideline cần thống nhất vẽ box theo phần nhìn thấy được (visible box) hay vẽ ước lượng bao hàm toàn bộ vật thể bị che khuất (amodal box).
  3. *Quy trình Escalation:* Khi gặp các ca che khuất nghiêm trọng (> 50%) hoặc ranh giới giữa các vật thể quá nhập nhằng, annotator phải gắn cờ báo cáo lên QC Lead / SME để nhận chỉ thị thống nhất cho toàn dự án.

## 3. Phân đoạn theo từng đối tượng – polygon cho mỗi instance

Nguồn evidence: `segmentation_predictions.json` và `visuals/segmentation_prediction.png`, sample `kitchen`.

- Một record (`instance_id`, `class_name`, `score`, số điểm và một phần `polygon_xy`):
  - `instance_id`: "kitchen-001"
  - `class_name`: "person"
  - `score`: 0.899318
  - `polygon_point_count`: 348
  - `bbox_xyxy`: `[385.45, 66.44, 498.02, 348.58]`
  - Một phần `polygon_xy` (3 điểm đầu và 3 điểm cuối):
    `[[446.0, 70.0], [445.0, 71.0], [444.0, 71.0], ..., [492.0, 289.0], [492.0, 287.0], [446.0, 70.0]]`
  *(Diễn giải hình học bằng lời: Đa giác khép kín gồm 348 điểm đỉnh uốn lượn liên tục bám khít đường biên giải phẫu của người đầu bếp: từ chỏm đầu, viền tóc xoăn, vai áo trắng, cánh tay, dây đeo yếm, tà tạp dề rủ xuống cho đến ống quần đen và giày).*

- Polygon bổ sung chi tiết gì so với box?
  Bounding box chỉ cung cấp phạm vi hình chữ nhật thô bao bọc đối tượng, vô tình chứa rất nhiều pixel ngoại lai thuộc về phông nền (như khoảng tường trống hai bên đầu, vùng giữa cánh tay và hông, nền sàn giữa hai chân). Ngược lại, **polygon** bổ sung thông tin hình học chính xác ở cấp độ điểm ảnh (pixel-level geometry):
  - Tách bạch chuẩn xác hình dáng thực (contour) uốn lượn phức tạp của đối tượng ra khỏi nền không gian xung quanh.
  - Phản ánh được các vùng rỗng hoặc phần khuyết (ví dụ: polygon của bàn bếp `kitchen-005` khoét rỗng các vị trí đặt bát đĩa, lọ gia vị và thanh cán bột trên mặt bàn).
  - Cung cấp cơ sở đo đạc diện tích thực tế (pixel mask area) và định hướng tư thế chính xác của vật thể trong không gian 2D/3D.

- `instance_id` dùng để làm gì và không phải loại ID nào?
  - `instance_id` (ví dụ `kitchen-001`, `kitchen-002`) là mã định danh duy nhất dùng để phân biệt từng thực thể cá thể riêng lẻ (individual instance) trong cùng một bức ảnh của bộ output thực hành, cho phép phân biệt giữa các đối tượng cùng một lớp (ví dụ giữa người đầu bếp đứng `kitchen-001` và bàn tay ở mép trái `kitchen-009`, hoặc giữa các chiếc bát khác nhau `kitchen-002`, `kitchen-003`, `kitchen-006`).
  - `instance_id` **không phải là class ID** (class ID là mã định danh của chủng loại, ví dụ `class_id = 0` áp dụng chung cho mọi đối tượng thuộc lớp `person`).
  - `instance_id` **không phải là tracking ID** (tracking ID là mã định danh đối tượng được bảo toàn liên tục xuyên suốt chuỗi frame video theo thời gian để theo vết hành trình chuyển động).

- Đề xuất một quy tắc biên mask:
  *Quy tắc Đường Biên Mặt Nạ Khép Kín (Mask Boundary Snapping Rule):* Đa giác phân đoạn phải là một chuỗi điểm khép kín liên tục bám sát đường biên quang học nhìn thấy được của đối tượng với dung sai tối đa không quá 1 - 2 pixel; tuyệt đối không bao gồm pixel của nền ngoại lai và không được chồng lấn (overlap) vô căn cứ sang diện tích của vật thể tiếp xúc lân cận.

- Với vùng mờ/tiếp xúc/che khuất, điều gì cần guideline hoặc escalation quyết định?
  1. *Ranh giới tiếp xúc giữa hai vật thể (Contact Edge):* Khi hai vật thể nằm đè lên nhau (ví dụ: đáy bát sứ tiếp xúc với mặt bàn bếp), guideline phải phân định rõ đường biên tiếp xúc thuộc về vật thể ở lớp trước (occluding / front object) để tránh xung đột điểm ảnh thuộc về cả hai mặt nạ.
  2. *Vùng chuyển tiếp mờ hoặc bóng đổ (Soft Shadow / Motion Blur):* Guideline cần xác định đường biên dừng lại ở ranh giới cấu trúc vật lý sắc nét hay mở rộng bao trùm cả vùng bóng mờ chuyển tiếp.
  3. *Vật thể bị che khuất phân mảnh (Occluded Multi-part):* Khi một vật thể bị một vật khác chắn ngang tạo thành 2 vùng nhìn thấy tách biệt, guideline cần quy định gán nhãn dưới dạng Multi-Polygon cho cùng một `instance_id` hay tách thành 2 instance khác nhau.
  4. *Escalation:* Trong các trường hợp vùng biên quá tối hoặc tương phản quá kém không thể phân biệt bằng mắt, annotator phải gắn cờ báo cáo lên cấp Reviewer / SME để thống nhất quy chuẩn.

## 4. Vòng đời và kiểm tra chất lượng

`ảnh thô → guideline → ground truth → huấn luyện → prediction → QC/rework`

| Tác vụ | Đơn vị/định dạng ground truth | Lỗi hoặc điểm mơ hồ quan sát được | Annotator làm gì? | Reviewer xem gì? |
| --- | --- | --- | --- | --- |
| Phân loại ảnh | 1 nhãn lớp (`class_id`, `class_name`) kèm tên `taxonomy_name` gán cho toàn bộ ảnh (`image_level_label`). | Ảnh `traffic` có nhiều loại phương tiện (xe buýt to tiền cảnh, ô tô con, xe máy, người đi bộ) nhưng mô hình gán `cab` rank 1 (score 0.51). | Đọc kỹ guideline về quy tắc chọn chủ thể chính (salience/dominance); gán nhãn theo đúng danh mục taxonomy; gắn cờ đề xuất chuyển sang multi-label nếu ảnh quá phân tán. | Kiểm tra nhãn có tuân thủ đúng quy tắc ưu tiên chủ thể trong guideline không; kiểm tra tính đồng nhất trên toàn bộ dataset; từ chối (reject) nếu annotator gán nhãn theo cảm tính. |
| Phát hiện vật thể | Danh sách các hộp chữ nhật 2D: `[x_min, y_min, x_max, y_max]` theo pixel kèm `class_id` cho từng vật thể. | Mô hình bỏ sót các cốc, bát gia vị nhỏ ở threshold 0.35; gán nhãn `person` cho bàn tay bị cắt sát mép trái ảnh `kitchen` (score 0.61). | Vẽ box ôm sát tất cả các vật thể nhìn thấy rõ theo class list; đối chiếu guideline về tỷ lệ hiển thị tối thiểu để quyết định vẽ hay bỏ qua phần cánh tay ở mép ảnh. | Phóng to kiểm tra độ chặt của 4 cạnh box (tightness); rà soát lỗi bỏ sót vật thể (under-annotation) và lỗi vẽ nhầm vào bóng râm/phông nền (false positives). |
| Instance segmentation | Đa giác khép kín (`polygon_xy`) kèm `class_id` và `instance_id` riêng biệt cho từng đối tượng đơn lẻ. | Mô hình nhận diện nhầm chùm lá khô treo trên trần thành `potted plant` (score 0.63); mặt nạ bàn bếp `kitchen-005` bị lẹm và phân tách phức tạp. | Dùng công cụ đa giác/brush viền khít đường biên quang học của từng đối tượng; tách ranh giới rõ ràng tại các điểm tiếp xúc; không gán nhãn đối tượng ngoài taxonomy. | Phóng to kiểm tra độ chính xác từng điểm ảnh viền (pixel tightness); kiểm tra không có hiện tượng chồng lấn mask giữa các instance tiếp xúc; kiểm tra tính toàn vẹn của đa giác. |

## 5. An toàn dữ liệu

- Một quy tắc bảo vệ dữ liệu:
  Tuyệt đối không tải lên, lưu trữ hoặc chia sẻ công khai dữ liệu định danh cá nhân nhạy cảm (PII: họ tên, CCCD/CMND, số điện thoại, email, khuôn mặt người, biển số xe) hoặc dữ liệu nội bộ, thông tin bí mật kinh doanh của doanh nghiệp lên các kho lưu trữ công cộng (GitHub Public, Google Drive Public, Colab Public). Chỉ thao tác trên dữ liệu mẫu công khai đã được cấp phép rõ ràng (như tập ảnh COCO bản quyền Creative Commons CC BY 2.0 đã qua xác thực checksum).

- Nếu thấy ảnh hoặc dữ liệu không đúng phạm vi, tôi sẽ dừng và báo cho:
  Giảng viên phụ trách môn học, Lab Coach / Mentor hướng dẫn trực tiếp, và bộ phận Quản trị & An toàn Dữ liệu (Data Governance / DPO) của chương trình đào tạo.

## 6. Danh sách bằng chứng

- [x] `classification_predictions.json`
- [x] `detection_predictions.json`
- [x] `segmentation_predictions.json`
- [x] `IMAGE_ATTRIBUTION.md`
- [x] `visuals/classification_top5.png`
- [x] `visuals/detection_predictions.png`
- [x] `visuals/segmentation_prediction.png`
- [x] Ô validation cuối notebook báo `PASS`.
- [x] Không có họ tên, MSSV hoặc dữ liệu nhạy cảm trong báo cáo/output.
